import { Injectable } from '@nestjs/common';

@Injectable()
export class FedExAppService {
  getHello(): string {
    return 'Hola soy el Microservicio FedEx';
  }
}
