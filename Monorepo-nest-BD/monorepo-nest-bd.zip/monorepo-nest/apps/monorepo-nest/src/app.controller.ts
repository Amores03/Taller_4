import { Body, Controller, Post } from '@nestjs/common';
import { AppService } from './app.service';

@Controller() // Marca esta clase como un controlador
export class AppController {
    constructor(private readonly _appService: AppService) {
        // Constructor para inyectar AppService
    }

    @Post('nuevo_paquete') // Define un endpoint POST accesible en /new-user
    public async nuevoPaquete(@Body() body: unknown) {
        // Objeto de usuario falso predeterminado
        const fakeUser = {
            email: 'fake_user@microservice.com',
            name: 'Fake User',
            avatar: 'https://fake-image.com',
            password: 'FakePassword_1234'
        };
    
        // Si el cuerpo de la solicitud está vacío, asigna fakeUser a body
        if (!body || Object.keys(body).length === 0) {
            body = fakeUser;
        }
    
        // Verifica que body es un objeto con las propiedades name y email
        if (typeof body === 'object' && body !== null) {
            const { name, email } = body as { name: string; email: string };
    
            if (typeof name === 'string' && typeof email === 'string') {
                // Llama al método newUser de AppService con el cuerpo modificado
                return this._appService.nuevoPaquete({ name, email });
            }
        }
    
        // Lanza un error si body no tiene el formato esperado
        throw new Error('El formato de body es inválido o incompleto.');
    }
}

// import { Body, Controller, Get, Post } from '@nestjs/common';
// import { AppService } from './app.service';

// //ESTA ES LA APP PRINCIPAL
// @Controller()
// export class AppController {
//   constructor(private readonly appService: AppService) {}

//   @Post()
//   nuevoPaquete(@Body() body:any): string {
//     return this.appService.nuevoPaquete(body);
//   }
// }
