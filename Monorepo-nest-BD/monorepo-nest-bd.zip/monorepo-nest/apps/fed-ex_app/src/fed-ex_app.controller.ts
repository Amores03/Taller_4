import { Controller, Get } from '@nestjs/common';
import { FedExAppService } from './fed-ex_app.service';
import { EventPattern } from '@nestjs/microservices';

@Controller()
export class FedExAppController {
  constructor(private readonly fedExAppService: FedExAppService) {}

  // @Get()
  // getHello(): string {
  //   return this.fedExAppService.getHello();
  // }

  // Eventos:
  @EventPattern('nuevo_paquete')
  manejarPaquete(data:any){
    console.log('Este es el paquete entrante', data)
  }
}
