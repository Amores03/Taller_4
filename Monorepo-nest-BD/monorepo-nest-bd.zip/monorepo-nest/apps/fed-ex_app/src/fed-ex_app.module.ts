import { Module } from '@nestjs/common';
import { FedExAppController } from './fed-ex_app.controller';
import { FedExAppService } from './fed-ex_app.service';

@Module({
  imports: [],
  controllers: [FedExAppController],
  providers: [FedExAppService],
})
export class FedExAppModule {}
