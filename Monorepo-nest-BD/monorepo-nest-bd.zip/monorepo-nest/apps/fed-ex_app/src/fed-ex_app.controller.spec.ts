import { Test, TestingModule } from '@nestjs/testing';
import { FedExAppController } from './fed-ex_app.controller';
import { FedExAppService } from './fed-ex_app.service';

describe('FedExAppController', () => {
  let fedExAppController: FedExAppController;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      controllers: [FedExAppController],
      providers: [FedExAppService],
    }).compile();

    fedExAppController = app.get<FedExAppController>(FedExAppController);
  });

});
