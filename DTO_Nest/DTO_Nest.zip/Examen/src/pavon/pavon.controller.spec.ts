import { Test, TestingModule } from '@nestjs/testing';
import { PavonController } from './pavon.controller';

describe('PavonController', () => {
  let controller: PavonController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PavonController],
    }).compile();

    controller = module.get<PavonController>(PavonController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
