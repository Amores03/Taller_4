import { PavonController } from './pavon.controller';
import { PavonService } from './pavon.service';
import { Module } from '@nestjs/common';

@Module({
    controllers: [PavonController],
    providers: [PavonService]
})
export class PavonModule {}
