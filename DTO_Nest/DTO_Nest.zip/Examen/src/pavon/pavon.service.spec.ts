import { Test, TestingModule } from '@nestjs/testing';
import { PavonService } from './pavon.service';

describe('PavonService', () => {
  let service: PavonService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PavonService],
    }).compile();

    service = module.get<PavonService>(PavonService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
