import { Controller, Get, Render } from '@nestjs/common';
import { PavonService } from './pavon.service';
import { get } from 'http';

@Controller('pavon')
export class PavonController {
    constructor(private readonly pavon : PavonService){}

    @Render('index')
    @Get()
    getPavoncito(){
        var message : string = this.pavon.getPavon();
        return {message};
    }
}
