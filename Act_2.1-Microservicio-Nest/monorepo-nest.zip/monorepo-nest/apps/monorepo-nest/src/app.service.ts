import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';

@Injectable()
export class AppService {

  constructor(@Inject('FedEx_SERVICE') private paqueteFedEx:ClientProxy){

  }

  getHello(): string {
    return 'Hola soy la APP principal';
  }

  nuevoPaquete(user:any){
    this.paqueteFedEx.emit('nuevo_paquete', user)
    return 'Paquete en proceso...'
  }
}
