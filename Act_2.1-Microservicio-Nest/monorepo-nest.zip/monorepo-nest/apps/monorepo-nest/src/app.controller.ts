import { Body, Controller, Get, Post } from '@nestjs/common';
import { AppService } from './app.service';

//ESTA ES LA APP PRINCIPAL
@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Post()
  nuevoPaquete(@Body() body:any): string {
    return this.appService.nuevoPaquete(body);
  }
}
